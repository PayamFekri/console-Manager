﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace End_of_the_fotball_project
{
    internal class Endclub
    {
    }
}
