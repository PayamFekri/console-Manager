﻿namespace End_of_the_fotball_project
{
    internal class Coach
    {
    }
}